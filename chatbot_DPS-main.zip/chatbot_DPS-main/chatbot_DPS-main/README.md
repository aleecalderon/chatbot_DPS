# Chatbot DPS

Proyecto desarrollado en React para brindar soporte automatizado a estudiantes.

## Arquitectura

El sistema está estructurado de forma modular:

- components/
- data/
- styles/

## Tecnologías utilizadas

- React
- JavaScript
- GitHub Copilot
- Git

## Desarrollado por:
- **Alejandra Cristal Calderón Escobar** – CE231635  
- **Francisco Armando Morales Flores** – MF230357  
- **Daniel Alexander Girón Cornejo** – GC221469  
- **Geisel Gabriela Castellanos Flores** – CF231034  
- **Gladis del Carmen Rivas Miranda** – RM191684  
