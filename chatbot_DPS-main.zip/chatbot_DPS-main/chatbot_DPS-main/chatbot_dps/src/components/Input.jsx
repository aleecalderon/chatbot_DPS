import React from "react";

function Input() {
  return (
    <div>
      <input type="text" placeholder="Escribe tu mensaje..." />
      <button>Enviar</button>
    </div>
  );
}

export default Input;
