import React, { useState } from "react";
import "../styles/Chatbot.css";

function Chatbot() {
  const [messages, setMessages] = useState([
    { text: "¡Hola! Soy el asistente virtual. ¿En qué puedo ayudarte?", sender: "bot" }
  ]);

  return (
    <div className="chatbot-container">
  <div className="chatbot-header">Asistente DPS</div>
  <div className="chat-window">
     {/* Mapeo de mensajes aquí */}
     <Message type="bot" text="¡Hola! ¿Cómo puedo ayudarte?" />
     <Message type="user" text="Hola, quiero información." />
  </div>
  <Input />
</div>
  );
}

export default Chatbot;
