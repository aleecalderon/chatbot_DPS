import React from "react";
import Chatbot from "./components/Chatbot";

function App() {
  return (
    <div>
      <Chatbot />
    </div>
  );
}

export default App;
